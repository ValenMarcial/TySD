from bottle import route, run, static_file
from datetime import datetime

@route('/')
def server_static():
    return static_file('index.html', root='./public')

@route('/<filepath:path>')
def server_static(filepath):
    return static_file(filepath, root='./public')

# serve /time resource
@route('/time')
def time():
    t = datetime.now()
    return {"hour": t.hour, "minutes": t.minute, "seconds": t.second}

if __name__ == '__main__':
    run(host='localhost', port=8080, debug=True)
